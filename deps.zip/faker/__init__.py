VERSION = '0.7.17'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
