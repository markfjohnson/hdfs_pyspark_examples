from .. import Provider as ColorProvider


class Provider(ColorProvider):
    pass
